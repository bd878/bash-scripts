#!/bin/bash

# Outputs list of choices using
# here doc

if [ $# -ne 1 ]; then
  echo "Usage: ./choices.sh file"
  exit 1;
fi

echo "Select an archive programm: "
doc=`cat <<ARCHIVES
compress
zip
gzip
bzip2
ARCHIVES`
echo "$doc"

read archive
echo "$doc" | grep "\<$archive\>" - 

if [ $? -ne 0 ]; then
  echo "Wrong choice: $archive"
  exit 1
else
  echo "Accepted: $archive"
  exit 0
fi
